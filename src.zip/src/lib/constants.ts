export const defaultAllowedPages = [
    "dashboard",
    "sales-invoices",
    "bank-transactions",
    "all-transactions-ledger",
    "chart-of-accounts",
    "purchases-bills",
    "contacts",
    "journal-entry",
    "document-reader",
    "historical-reference-data",
    "bank-reconciliation",
    "financial-reports",
    "management-reports"
  ];